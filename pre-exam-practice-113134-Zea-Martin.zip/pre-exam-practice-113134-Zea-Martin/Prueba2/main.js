$(document).ready(function () {
    $("#pilotForm").validate({
        onkeyup: false, // Agrega esta línea
        rules: {
            nombre: {
                required: true,
                maxlength: 30
            },
            apellido: {
                required: true,
                maxlength: 20
            },
            horasVuelo: {
                required: true,
                min: 50
            },
            tipoVuelo: {
                required: true
            },
            nacionalidad: {
                required: true
            }
        },
        messages: {
            nombre: {
                required: "Por favor, ingrese un nombre",
                maxlength: "El nombre no debe tener más de 30 caracteres"
            },
            apellido: {
                required: "Por favor, ingrese un apellido",
                maxlength: "El apellido no debe tener más de 20 caracteres"
            },
            horasVuelo: {
                required: "Por favor, ingrese la cantidad de horas de vuelo",
                min: "La cantidad de horas de vuelo debe ser al menos 50"
            },
            tipoVuelo: {
                required: "Por favor, seleccione un tipo de vuelo"
            },
            nacionalidad: {
                required: "Por favor, seleccione una nacionalidad"
            }
        },
        errorElement: 'li',
        errorLabelContainer: '.alert ul',
        invalidHandler: function (event, validator) {
            let errors = validator.numberOfInvalids();
            if (errors) {
                $(".alert").show();
            } else {
                $(".alert").hide();
            }
        },
        submitHandler: function (form) {
            alert("La carga fue exitosa");
            window.location.href = "siguientePagina.html";
        }
    });
});  