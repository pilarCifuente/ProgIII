$(document).ready(function() {
    let validUsername = "tup2022@tup.com.ar";
    let validPassword = "123456";
  
    $("#loginForm").validate({
      rules: {
        username: {
          required: true,
        },
        password: {
          required: true,
        }
      },
      messages: {
        username: {
          required: "Por favor, ingrese un usuario",
        },
        password: {
          required: "Por favor, ingrese una clave",
        }
      },
      submitHandler: function(form) {
        let username = $("#username").val();
        let password = $("#password").val();
  
        if (username === validUsername && password === validPassword) {
          // Redirige al usuario a la siguiente página
          window.location.href = "altaPiloto.html";
        } else {
          // Muestra un mensaje de error
          alert("Usuario o clave incorrectos");
        }
      }
    });
  });
  