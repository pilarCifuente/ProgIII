$("form").validate({
    rules: {
        nombre: {
            required: true,
            maxlength: 30
        },
        apellido: {
          required: true,
          maxlength: 20
        },
        cantHoras:{
            required: true,
            min: 50
        },
        nacionalidad:{
            range: [1,2]
        }
    },messages: {
        nombre: {
            required: "El campo nombre es requerido",
            maxlength: "El campo nombre no puede tener mas de 30 caracteres"
        },
        apellido: {
            required: "El campo apellido es requerido",
            maxlength: "El campo apellido no puede tener mas de 20 caracteres"
        },
        cantHoras: {
            required: "El campo cant.Horas es requerido",
            min: "La cantidad de horas debe ser mayor a 50"
        },
        nacionalidad:{
            range: "Debe seleccionar una nacionalidad"
        }
    },
    showErrors: function(errorMap, errorList) {
        $("#errorContainer").html("");
        if(errorList.length > 0){
            $("#errorContainer").append('<h3>Errores en el formulario</h3>');
            $("#errorContainer").show()}
            
        else
        $("#errorContainer").hide();
        $.each(errorList, function(index, error){
            $("#errorContainer").append('<li class="lista-errores">'+error.message+'</li>');
        })
    }

})



